@interface TestFairyUnityWrapper : NSObject
@end